# House-rental-system
The house rental system project aims to streamline the process of renting properties. Users can search for available houses based on their preferences, such as location, size, and amenities. Landlords can list their properties with detailed descriptions, facilitating easy access for potential tenants. The system includes features for payment processing functionalities for rent collection.The project enhances efficiency in the rental process, providing a user-friendly platform for both landlords and tenants to interact and manage rental transactions seamlessly.

![image](https://github.com/khushi2411/House-rental-system/assets/103480054/416ac65b-7f2e-4cbe-8af4-30a4b0e26740)
